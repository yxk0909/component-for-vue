<template>
	<div class="index">
	</div>
</template>

<script>
	export default {
	};
</script>

<style lang="less" scoped>
	.index {
		position: relative;
	}
</style>

