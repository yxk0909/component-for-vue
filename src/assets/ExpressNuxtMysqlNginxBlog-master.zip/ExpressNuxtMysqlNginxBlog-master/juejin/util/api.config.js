module.exports = {
    needAuth: [
        '/api/post/add',
        '/api/post/update',
    ]
}